/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.elecciones_mintic;

import Clases.ClsJdbc;
import Vistas.FrameMenu;
import javax.crypto.AEADBadTagException;

/**
 *
 * @author leiner
 */
public class Elecciones_mintic {

    public static void main(String[] args) {      
        ClsJdbc jdbc = new ClsJdbc();
        jdbc.crearConexion();
        
        FrameMenu menu = new FrameMenu();
        menu.setLocationRelativeTo(menu);
        menu.setVisible(true);        
    }
}
